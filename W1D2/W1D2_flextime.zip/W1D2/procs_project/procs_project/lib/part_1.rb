def my_map(arr, &prc)
    mapped = []
    arr.each do |ele|
        mapped << prc.call(ele)
    end
    mapped
end

def my_map(arr)
    mapped = []
    arr.each do |ele|
        mapped << ele * 2
    end
    mapped
end

p my_map([1,2,3]) { |n| n * 2 } # Result: [2,4,6]
# p my_map([4,8,12,20]) { |n| n * 2 } # Result: [8,16,24,40]

arr1 = [1,2,3,4,5,6]
arr1.map {|num| num * 888899999}



def my_select(arr, &prc)
    selected = []
    arr.each do |ele|
        selected << ele if prc.call(ele) == true
    end
    selected
end

def my_count(arr, &prc)
    count = 0
    arr.each do |ele|
        count += 1 if prc.call(ele)
    end
    count
end

def my_any?(arr, &prc)
    count = 0
    arr.each do |ele|
        count += 1 if prc.call(ele)
    end
    count > 0 
end

def my_all?(arr, &prc)
    count = 0
    arr.each do |ele|
        count += 1 if prc.call(ele)
    end
    count == arr.length
end

def my_none?(arr, &prc)
    count = 0
    arr.each do |ele|
        count += 1 if prc.call(ele)
    end
    count == 0
end


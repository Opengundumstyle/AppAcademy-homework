# TDD
    # Write Test(s)
    # Run the test(s)
    # Implement changes to satisfy the test (coding)
    # Run Test(s)


# BLOCKS
    # do ... end will mark beginning and end of a block
    # { ... }

# PROCS
    # doubler = Proc.new { |num| num * 2 }
    # p doubler.call(5)

    

    # METHOD THAT TAKES A PROC
    def add_and_proc(num1, num2, prc)
        sum = num1 + num2
        result = prc.call(sum)
    end

    # p add_and_proc(3, 4, doubler) # 14


    #METHOS THAT TAKES A BLOCK AS A PROC
    def add_and_proc(num1, num2, &banana)
        sum = num1 + num2
        result = banana.call(sum)
    end

    # p add_and_proc(3, 4) { |num| num * 2 }




    # Benefit of PROCS

    # arr1 = [1,2,3,4,5,6]
    # result = arr1.map {|num| num * 2}
    # p result

    def my_map(arr, &prc)
        mapped = []
        arr.each do |ele|
            mapped << prc.call(ele)
        end
        mapped
    end
    
    def my_map(arr)
        mapped = []
        arr.each do |ele|
            mapped << ele * 2
        end
        mapped
    end
    
    # p my_map([1,2,3]) { |n| n * 2 } # Result: [2,4,6]
    # # p my_map([4,8,12,20]) { |n| n * 2 } # Result: [8,16,24,40]
    
    # arr1 = [1,2,3,4,5,6]
    # arr1.map {|num| num * 888899999}

    doubler = Proc.new { |num| num * 2 }
    tripler = Proc.new { |num| num * 3 }
    to_string = Proc.new { |num| num.to_s }


    def many_procs_taken(banana1, banana2, banana3, num, &block_passed_in)
        step1 = banana1.call(num)
        step2 = banana2.call(step1)
        result = banana3.call(step2)
        block_passed_in.call(result)
    end

    # p many_procs_taken(doubler, tripler, to_string, 5) {|str| str + "!!!!"}


    #TEAMWORK:

    # word_changer

    # "should accept a sentence string and a block as args" - Note that it accepts a block meaning we will need to use the & to convert the block parameter to a proc.
    # "should return a new sentence where every word becomes the result of the block when passed the original word of the sentence"

    def word_changer(sentence, &prc)
        # new_sent = []
        words = sentence.split
        # words.map {|word| prc.call(word)}.join(" ")
        new_words = words.map do |word|
            prc.call(word)
            # new_sent << word
        end
        return new_words.join(" ")
    end

    p word_changer("I wish you all the best of days") { |word| word.upcase + "!" }

    # sentence1 = "I wish you all the best of days"
    # block1 = { |word| word.upcase + "!" }
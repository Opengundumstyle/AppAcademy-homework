def all_words_capitalized?(arr)
    arr.all? {|word| word[0] == word[0].upcase && word[1..-1] == word[1..-1].downcase}
end

def no_valid_url?(arr)
    valid_urls = ['.com', '.net', '.io', '.org']
    arr.none? do |url|
        valid_urls.any? {|dot_x| url.include?(dot_x)}
    end
end

def any_passing_students?(arr)
    arr.any? do |student|
        (student[:grades].sum / student[:grades].length) >= 75
    end
end